/*function rouge(a) {
    var button = document.getElementById("rond" + a);
        button.className = "rond rond"+ a + " rouge";
    }
*/
function rouge(a) {
    var button = document.getElementsByClassName("rond");
    for (var i = 0; i < button.length; i++);
    var btn = button[i];
    /*if ((button.className.match(/(?:^|s)rond rond1 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond2 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond3 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond4 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond5 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond6 rouge(?!S)/)) ){
        button.className = button.className.replace( /(?:^|\s)rouge(?!\S)/g , '' );
*/
    if (btn.classList.contains("rouge")){
        btn.classList.remove("rouge");
    } else {
        btn.classList.add("rouge");
    }

    var texte = document.getElementById("block" + a);
    //console.log(document.getElementById("block" + a))
    //console.log(texte[i])
    //for (var i = 0; i < texte.length; i++){
        
    
        //var text = texte[i];
        
        if (texte.style.display === "none") {
            texte.style.display = "block";
        } else {
            texte.style.display = "none";
        }
    
    }
    





/*function rouge(a) {
    var button = document.getElementById("rond" + a);
    if ((button.className.match(/(?:^|s)rond rond1 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond2 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond3 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond4 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond5 rouge(?!S)/)) || (button.className.match(/(?:^|s)rond rond6 rouge(?!S)/)) ){
        button.className = button.className.replace( /(?:^|\s)rouge(?!\S)/g , '' );

    } else {
        button.className = "rond rond" + a + " rouge";
    }
}*/







/*document.querySelector('#rond1').addEventListener('click', function (e) {
    if (e.ClassName === "rond"){
        e.ClassName = "rouge";
    }
}    
button.addEventListener('click', event => {
    button.className = "rouge";
  }); */